# 地图节点透明素材

来源：`E:\CjnxSQpp.png`，1920×1072 RGB PNG。包含 18 种节点中心图案和 1 枚独立通用底座。

## 文件

- `native`：按原图像素切出的 RGBA PNG，裁去多余空白，四周另留 16 像素透明边距。优先用于后续编辑。
- `png512`：统一 512×512 透明画布，以相同的 1.2 倍导出比例安排主体和落脚基准，保留三级敌人的相对体量。512 是画布尺寸，不代表原图增加了高清细节。
- `png128`：由 512 版缩小的 128×128 RGBA PNG，供游戏尺寸预览；尚未接入。
- `preview-dark.png` / `preview-light.png`：深浅背景对照。背景和名称只在预览图中，不在独立素材中。
- `preview-small.png`：上排 84、下排 64 像素的阅读检查，编号对应下表。
- `extraction-report.json`：来源哈希、裁切坐标、透明范围及导出说明。
- `extract_nodes.py`：本地可复现处理脚本，使用 Pillow、NumPy、OpenCV，不调用生成模型或生图 API。
- `diagnostics` / `background-model.png`：处理过程检查文件，不必导入游戏，交付压缩包中不含这些中间图。

| 编号 | 文件 | 内容 |
| --- | --- | --- |
| 01 | node-start.png | 入境处 |
| 02 | node-transit.png | 空节点 |
| 03 | node-enemy-normal.png | 普通敌人 |
| 04 | node-enemy-elite.png | 精英敌人 |
| 05 | node-enemy-boss.png | 首领 |
| 06 | node-supply.png | 补给处 |
| 07 | node-search.png | 搜索点 |
| 08 | node-borrow.png | 借法台 |
| 09 | node-insight.png | 悟道处 |
| 10 | node-recovery.png | 恢复点 |
| 11 | node-extract.png | 撤离点 |
| 12 | node-battle-loot.png | 战后遗藏 |
| 13 | node-herb.png | 药品采集处 |
| 14 | node-ore.png | 矿石采集处 |
| 15 | node-chest-common.png | 普通宝箱 |
| 16 | node-chest-refined.png | 精制宝箱 |
| 17 | node-chest-treasure.png | 珍藏宝箱 |
| 18 | node-cave.png | 洞府 |
| 19 | node-base.png | 通用底座 |

## 处理与检查

从原图估算棋盘格，提取封闭主体轮廓，对被光效打断的实体部分补充遮罩；边缘反混色，光效单独恢复为半透明区域，避免把灰石和面甲当背景删除。

原图没有 alpha 或独立图层，所以不可能无损恢复原始透明度。入口、撤离、借法、悟道的半透明效果采用按原画方向与形状的近似恢复和去网格平滑，局部亮度、柔化程度可能与平铺原图不同，不宣称逐像素还原。

已检查 19×3 张独立 PNG 的 RGBA、透明角点、主体不裁边、部分透明边缘和实体像素，另以深浅底与 64/84 像素预览目检。原图不改动，现有游戏图片、导入设置、代码、配置和存档均未覆盖或修改；本目录是待确认素材，不是已接入版本。
